﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10._1Console
{/// <summary>
/// Author Ajay kumar
///  date: 09 May2019
/// </summary>
    class Program
    {
        public delegate int MyDelegate(int Num1, int Num2);
        static void Main(string[] args)
        {
            ArthematicOperation ao = new ArthematicOperation();
            Console.WriteLine("num1:");
            int number1 = int.Parse(Console.ReadLine());
            Console.WriteLine("num2:");
            int number2 = int.Parse(Console.ReadLine());
            string choice1;
            do
            {
                Console.WriteLine("select: ");
                Console.WriteLine("1. Add\n2.Sub\n3.Mul\n4.Max");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            MyDelegate mydelegate1 = new MyDelegate(ao.Add);
                            Console.WriteLine("addition is {0}", mydelegate1(number1, number2));
                            break;
                        }
                    case 2:
                        {
                            MyDelegate mydelegate1 = new MyDelegate(ao.Sub);
                            Console.WriteLine("Subtraction is {0}", mydelegate1(number1, number2));
                            break;
                        }
                    case 3:
                        {
                            MyDelegate mydelegate1 = new MyDelegate(ao.Mul);
                            Console.WriteLine("multiplication is {0}", mydelegate1(number1, number2));
                            break;
                        }
                    case 4:
                        {
                            MyDelegate mydelegate1 = new MyDelegate(ao.Max);
                            Console.WriteLine("Max number is {0}", mydelegate1(number1, number2));
                            break;
                        }
                }
                Console.WriteLine("to continue press y");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.ReadLine();
        }

        public class ArthematicOperation
        {
            public int Add(int num1, int num2)
            {
                int num = num1 + num2;
                return num;
            }


            public int Sub(int x, int y)
            {
                int z = x - y;
                return z;
            }

            public int Mul(int num1, int num2)
            {
                int num = num1 * num2;
                return num;
            }

            public int Max(int num1, int num2)
            {
                if (num1 > num2)
                    return num1;
                else
                    return num2;
            }
        }

    }
}
