﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class1
{/// <summary>
/// Author Ajay kumar
///  date: 09 May2019
/// </summary>
    public delegate int MyDelegate(int Num1, int Num2);
    public class ArithmeticOperations
    {
        public static int Add(int num1, int num2)
        {
            int num = num1 + num2;
            return num;
        }
        public static int Sub(int num1, int num2)
        {
            int num = num1 - num2;
            return num;
        }
        public static int Mul(int num1, int num2)
        {
            int num = num1 * num2;
            return num;
        }
        public static int Max(int num1, int num2)
        {
            if (num1 > num2)
                return num1;
            else
                return num2;
        }
    }
}
