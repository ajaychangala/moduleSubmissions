﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBook.Entities
{/// <summary>
/// Author: C.Ajay kumar
/// date: 10 May 2019
/// </summary>
    public class Guest
    {
        private int guestId;
        public int GuestId
        {
            get { return guestId; }
            set { guestId = value;}
        }
        private string guestName;
        public string GuestName
        {
            get { return guestName; }
            set { guestName = value; }
        }
        private string guestContactNumber;
        public string GuestContactNumber
        {
            get { return guestContactNumber; }
            set
            {
                guestContactNumber = value;
            }
        }
        public Guest()
        {
            guestId = 0;
            guestName = string.Empty;
            guestContactNumber = string.Empty;
        }

    }
}
