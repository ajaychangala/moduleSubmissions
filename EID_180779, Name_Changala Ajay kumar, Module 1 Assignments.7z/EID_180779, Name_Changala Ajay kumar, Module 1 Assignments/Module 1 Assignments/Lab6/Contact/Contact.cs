﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact
{/// <summary>
/// Author Ajay kumar
///  date: 07 May2019
/// </summary>
    public class Contact
    {
        public int ContactNo { get; set; }

        public string ContactName { get; set; }

        public string CellNo { get; set; }

    }
}
