﻿//console app******************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace Lab4._1Console
{/// <summary>
 /// Author : C.Ajay kumar
 /// Date: 07 May 2019
 /// </summary>
 /// <param name="args"></param>
    class Program
    {
        static void Main(string[] args)
        {
            Employee.ContractEmployee cemp = new ContractEmployee();
            cemp.AcceptData();
            cemp.GetSalary();

            PermanentEmployee pemp = new PermanentEmployee();
            pemp.AcceptData();
            cemp.GetSalary();

            cemp.DisplayData();
            pemp.DisplayData();
            Console.ReadLine();
        }
    }
}
//*****************************************