﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArithmeticOperations;

namespace Calc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*****ARITHMETIC OPERATIONS********");
            Console.WriteLine("1.Addition");
            Console.WriteLine("2.Subtraction");
            Console.WriteLine("3.Multiplication");
            Console.WriteLine("4.Division");
            Console.WriteLine("5.Modulus");
            Console.WriteLine("Enter User Choice");
            int UserChoice = Int32.Parse(Console.ReadLine());
            switch (UserChoice)
            {
                case 1:     //Addition
                    Class1 c1 = new Class1();
                    Console.WriteLine("Enter the first the number");
                    int a1 = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the second the number");
                    double a2 = Double.Parse(Console.ReadLine());
                    Console.WriteLine("the addition is : " + c1.Add(a1, a2));
                    break;
                case 2:     //Subtraction
                    Class1 c2 = new Class1();
                    Console.WriteLine("Enter the first the number");
                    int s1 = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the second the number");
                    double s2 = Double.Parse(Console.ReadLine());
                    Console.WriteLine("the Subtraction of two numbers  is : " + c2.Sub(s1, s2));
                    break;
                    
                case 3:     //Multiplication
                    Class1 c3 = new Class1();
                    Console.WriteLine("Enter the first the number");
                    int m1 = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the second the number");
                    double m2 = Double.Parse(Console.ReadLine());
                    Console.WriteLine("the multiplication of two numbers is : " + c3.Mul(m1, m2));
                    break;

                case 4:    //Division
                    Class1 c4 = new Class1();
                    Console.WriteLine("Enter the first the number");
                    int d1 = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the second the number");
                    double d2 = Double.Parse(Console.ReadLine());
                    Console.WriteLine("the division of two numbers is : " + c4.Div(d1, d2));
                    break;

                case 5:    //Modulus
                    Class1 c5 = new Class1();
                    Console.WriteLine("Enter the first the number");
                    int md1 = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the second the number");
                    double md2 = Double.Parse(Console.ReadLine());
                    Console.WriteLine("the Modulus of two numbers is : " + c5.Mod(md1, md2));
                    break;

            }
                    Console.ReadLine();

        }
    }
}
