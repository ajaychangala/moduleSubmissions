﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SfmDAL;
using SfmEntities;
using SfmExceptions;

namespace SfmBLL
{
    /// <summary>
    /// empId :180779
    /// Author: Changala ajay kumrar
    /// date 8 May 2019
    /// </summary>
    public class DealerBLL
    {/// <summary>
    /// Business logic layer
    /// </summary>
    /// <param name="d"></param>
        public void AddDealer(Dealer d)
        {//validating dealer
            if (d.DealerID.Length<6)
            {
                throw new InvalidDealerIDException();
            }
            if(d.DealerID.Length > 6)
            {
                throw new InvalidDealerIDException();
            }
            if(d.DealerID.StartsWith("DL"))
            {
                return ;
            }
            if(d.DealerPhoneNo<10)
            {
                throw new InvalidDealerPhoneNoException();
            }
            if (d.DealerPhoneNo> 10)
            {
                throw new InvalidDealerPhoneNoException();
            }
            dealer.Add(d);

        }
        public IEnumerable<Dealer>GetDealers()
        {//getting dealer

            DealerDAL dal = new DealerDAL();
            return dal.GetAll();
        }
        public Dealer GetDealer(string DealerCategory)
        {
            if(DealerCategory == "Grocery")
            {
                return GetDealer(DealerCategory);
            }
            if (DealerCategory == "BakeryProducts")
            {
                return GetDealer(DealerCategory);
            }
            if (DealerCategory == "Vegetables")
            {
                return GetDealer(DealerCategory);
            }
            else
            {
                throw new DealerNotFoundException();
            }

            DealerDAL dal = new DealerDAL();
            return GetDealers;
        }
    }
}
