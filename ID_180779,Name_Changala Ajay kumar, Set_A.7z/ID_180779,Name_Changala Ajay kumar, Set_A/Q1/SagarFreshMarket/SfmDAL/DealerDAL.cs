﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SfmEntities;
using SfmExceptions;

namespace SfmDAL
{
    /// <summary>
    /// empId :180779
    /// Author: Changala ajay kumrar
    /// date 8 May 2019
    /// </summary>
    public class DealerDAL
    {
        /// <summary>
        /// data access layer
        /// </summary>
        private static List<Dealer> dealers = new List<Dealer>();
        
        public void Add(Dealer d)
        {//adding dealer
            dealers.Add(d);
        }
        //listing dealers
        public IEnumerable<Dealer>GetAll()
        {
            return dealers;
        }
    }
}
