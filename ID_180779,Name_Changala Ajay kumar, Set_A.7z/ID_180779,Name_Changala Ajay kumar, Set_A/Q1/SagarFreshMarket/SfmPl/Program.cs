﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SfmBLL;
using SfmEntities;
using SfmExceptions;

namespace SfmPl
{
    /// <summary>
    /// empId :180779
    /// Author: Changala ajay kumrar
    /// date 8 May 2019
    /// </summary>
    class Program
    {/// <summary>
    /// Presentation layer
    /// </summary>
    /// <param name="args"></param>
        static void Main(string[] args)
        {
            DealerBLL bll = new DealerBLL();
            while(true)
            {
                Console.WriteLine("Enter Choice");
                Console.WriteLine("1)Add dealer \n2)List dealer \n3)Search \n4)Exit");
                int choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    Dealer d = new Dealer();
                    Console.WriteLine("Enter ID");
                    d.DealerID = Console.ReadLine();
                    Console.WriteLine("Enter name");
                    d.DealerName = Console.ReadLine();
                    Console.WriteLine("Enter Address");
                    d.DealerAddress = Console.ReadLine();
                    Console.WriteLine("Enter MailID");
                    d.DealerEmailID = Console.ReadLine();
                    Console.WriteLine("Enter PhoneNo");
                    d.DealerPhoneNo = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Status");
                    d.DealerStatus = Console.ReadLine();
                    Console.WriteLine("Enter dealer category");
                    d.DealerProductCategory = Console.ReadLine();
                    bll.AddDealer(d);
                    Console.WriteLine("Dealer added successfullt");
                }
                else if(choice==2)
                {
                    var dealers = bll.GetDealers();
                    foreach(var d in dealers)
                    {
                        Console.WriteLine("{0,-3}|{1,-10}|{2,-4}|{4,-5}|{3,-6}|{3,-9}|{8,-9}",d.DealerID,d.DealerName,d.DealerEmailID,d.DealerAddress,d.DealerPhoneNo,d.DealerProductCategory,d.DealerStatus);
                    }

                }
                else if (choice ==3)
                {

                }
                else if(choice == 4)
                {
                    break;
                }
            }
        }
    }
}
