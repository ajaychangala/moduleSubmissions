﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SfmEntities
{
    /// <summary>
    /// empId :180779
    /// Author: Changala ajay kumrar
    /// date 8 May 2019
    /// </summary>
    [Serializable]
    public class Dealer
    {

        //Get or set dealer ID
        public string DealerID { get; set; }


        //Get or set Dealer Name
        public string DealerName { get; set; }

        //Get or set DealerAddress
        public string DealerAddress{ get; set; }

        //Get or set DealerEmailID
        public string DealerEmailID { get; set; }

        //Get or set PhoneNumber
        public int DealerPhoneNo { get; set; }

        //Get or set Dealer Satus
        public String DealerStatus { get; set; }

        //Get or set DealerProductCategory
        public string DealerProductCategory { get; set; }

    }
}
