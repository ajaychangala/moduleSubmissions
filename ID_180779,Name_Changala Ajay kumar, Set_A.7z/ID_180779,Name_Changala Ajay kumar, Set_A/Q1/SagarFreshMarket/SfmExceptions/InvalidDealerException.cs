﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SfmExceptions
{
    /// <summary>
    /// empId :180779
    /// Author: Changala ajay kumrar
    /// date 8 May 2019
    /// </summary>
    public class InvalidDealerException: Exception
    {
        string message = "Invalid dealer attributes";
        public override string Message
        {
            get { return message; }
        }

    }
}
