﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SfmExceptions
{
    /// <summary>
    /// empId :180779
    /// Author: Changala ajay kumrar
    /// date 8 May 2019
    /// </summary>
    public class InvalidDealerIDException: Exception
    {
        string message;
        public override string Message
        {
            get { return "Invalid dealer ID"; }
        }

    }
}
