﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SfmExceptions
{
    /// <summary>
    /// empId :180779
    /// Author: Changala ajay kumrar
    /// date 8 May 2019
    /// </summary>
    public class DealerNotFoundException : Exception 
    {
        string message = "Dealer you are searching for not found";
        public override string Message
        {
            get { return message; }
        }
    }
}
