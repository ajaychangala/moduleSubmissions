﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{ /// <summary>
/// empId :180779
/// Author: Changala ajay kumrar
/// date 8 May 2019
/// </summary>
    class Program
    {
        static void Main(string[] args)
        {//Display Details
            List<Employee> EmpList = new List<Employee>(int ID,string Name,String Location);

            EmpList.Add(new Employee(60, "Akash","Mumbai"));
            EmpList.Add(new Employee(80, "Akshay","Madurai"));
            EmpList.Add(new Employee(100, "Vishal","Amalapur"));
            EmpList.Add(new Employee(30, "karan","Kadapa"));
            EmpList.Add(new Employee(60, "Ajay", "Mumbai"));
            
            foreach (var v in EmpList)
            {
                Console.WriteLine(v. ID+ "\t" + v.Name + "\t" +"\t"+v.Location);
            }

         
            Console.WriteLine();
            


        }

    }
       
}    

