﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{ /// <summary>
/// empId :180779
/// Author: Changala ajay kumrar
/// date 8 May 2019
/// </summary>
    class Employee
    {//Entities
        public int ID { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }

       
       
    }
}
