﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountWords
{ /// <summary>
/// empId :180779
/// Author: Changala ajay kumrar
/// date 8 May 2019
/// </summary>
    class Sentence
    { //get sentence
       public string sentence { get; set; }
    }
}
