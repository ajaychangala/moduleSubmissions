﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountWords
{
 /// <summary>
/// empId :180779
/// Author: Changala ajay kumrar
/// date 8 May 2019
/// </summary>
    class Program
    { //Counting the words in Sentence
        static void Main(string[] args)
        {
            Sentence s = new Sentence();
            Console.WriteLine("Enter the sentence");
            s.sentence = Console.ReadLine();

        }
    }
}
