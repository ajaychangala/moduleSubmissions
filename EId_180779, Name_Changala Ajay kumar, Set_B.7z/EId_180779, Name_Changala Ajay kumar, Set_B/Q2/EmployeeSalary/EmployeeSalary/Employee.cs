﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalary
{
    /// <summary>
    /// Employee Id: 180779
    /// Author: Changala Ajay kumar
    /// Date of Creation: 28-05-2019
    /// </summary>
    public class Employee       //Base Class
    {
        //Employee Properties
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public double Basic { get; set; }
        public double HRA { get; set; }
        public double DA { get; set; }
        public double TA { get; set; }
        public double GrossSalary { get; set; }

        public Employee(int id,string name, double basic, double hra, double da, double ta)
        {
            this.EmpID = id;
            this.EmpName = name;
            this.Basic = basic;
            this.HRA = hra;
            this.DA = da;
            this.TA = ta;
        }

        //Virtual method of calculating Salary
        public virtual double CalculateSalary()
        {
            GrossSalary = Basic + HRA + DA + TA;
            return GrossSalary;
        }
    }


    public class Manager:Employee          //Derived Class
    {
        public double Incentives { get; set; }
        public Manager(int id, string name, double basic, double hra, double da, double ta,double ince):base(id,name,basic,hra,da,ta)
        {
            this.Incentives = ince;
        }

        //Overriding of CalculateSalary
        public override double CalculateSalary()
        {
            GrossSalary = Basic + HRA + DA + TA +Incentives;
            return GrossSalary;

        }
    }
}
