﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalary
{
    /// <summary>
    /// Employee Id: 180779
    /// Author: Changala Ajay kumar
    /// Date of Creation: 28-05-2019
    /// </summary>
    class Program
    {
        //Main Method
        static void Main(string[] args)
        {
            Employee emp = new Manager(101, "Anand", 30000, 5000, 18000, 1600, 3000);
            Console.WriteLine("Gross Salary : " +emp.CalculateSalary());
            Console.ReadKey();
        }
    }
}
