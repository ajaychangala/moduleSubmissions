﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using BSNLCMS_ENTITY;          //Reference of Entity layer
using BSNLCMS_EXCEPTIONS;      //Reference of Exception layer

namespace BSNLCMS_DAL
{
    /// <summary>
    /// EmpId:180779
    /// Author: Changala Ajay kumar
    /// Date of Creation:28-05-2019
    /// Description: Data Access Layer
    /// </summary>
    public class CustomerDAL
    {
        public static List<Customer> Customers = new List<Customer>();

        //Adding new Customer
        public bool AddCustomerDAL(Customer newCustomer)
        {
            bool isCustomerAdded = false;
            try
            {
                Customers.Add(newCustomer);
                isCustomerAdded = true;
            }
            catch (SystemException exception)
            {
                throw new CustomerExceptions(exception.Message);
            }
            return isCustomerAdded;
        }

        //Getting List of Customers
        public List<Customer> GetAllCustomersDal()
        {
            return Customers;
        }

        //Seatrching Customer by CustomerID
        public List<Customer> SearchByCustomerIDDal(string CustomerID)
        {
            return Customers.FindAll(Customer => Customer.CustomerID == CustomerID);
        }

        //Serailization of Customers
        public bool SerializeCustomersDal()
        {
            bool areCustomersSerialized = false;
            try
            {
                FileStream fileStream = new FileStream("Customersinfo.txt", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, Customers);
                fileStream.Close();
                areCustomersSerialized = true;
            }
            catch (SystemException exception)
            {
                throw new CustomerExceptions(exception.Message);

            }
            return areCustomersSerialized;
        }

        //Deserailization of Customers
        public List<Customer> DeserializedCustomersDal()
        {
            List<Customer> DeserializedCustomers;
            try
            {
                FileStream fileStream = new FileStream("Customersinfo.txt", FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                DeserializedCustomers = (List<Customer>)binaryFormatter.Deserialize(fileStream);
                fileStream.Close();
            }
            catch (SystemException exception)
            {
                throw new CustomerExceptions(exception.Message);

            }
            return DeserializedCustomers;
        }
    }
}
