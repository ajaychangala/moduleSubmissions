﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BSNLCMS_EXCEPTIONS
{
    /// <summary>
    /// EmpId:180779
    /// Author: Changala Ajay kumar
    /// Date of Creation:28-05-2019
    /// Description: Exception Layer
    /// </summary>
    public class CustomerExceptions:ApplicationException
    {
        public CustomerExceptions()
        {

        }
        public CustomerExceptions(string Message) : base(Message)
        {

        }
    }
}
