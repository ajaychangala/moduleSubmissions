﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BSNLCMS_BLL;                   //Reference of Business Logic layer
using BSNLCMS_ENTITY;                //Reference of Entity layer
using BSNLCMS_EXCEPTIONS;            //Reference of Exception layer

namespace BSNLCMS_PL
{ /// <summary>
  /// EmpId:180779
  /// Author: Changala Ajay kumar
  /// Date of Creation:28-05-2019
  /// Description: Presentation Layer
  /// </summary>
    class Program
    {

        static CustomerBLL CustomerBLL = new CustomerBLL();

        //Main Method
        static void Main(string[] args)
        {
            byte choice;
            do
            {
                PrintMenu();

                Console.WriteLine("Enter your Choice:");
                bool checkChoice;
                checkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!checkChoice) { Console.WriteLine("Invalid Input"); }
                //int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddCustomerPL();
                        break;
                    case 2:
                        GetAllCustomersPL();
                        break;
                    case 3:
                        SearchDealeerByCustomerIDPL();
                        break;
                    case 4:
                        SerializeCustomersPL();
                        break;
                    case 5:
                        DeserializedCustomersPL();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 0);
        }

        //Printing Menu
        public static void PrintMenu()
        {
            Console.WriteLine("************************BHARATH SANCHAR NIGHAM LIMITED ***************************");
            Console.WriteLine("**************************Customer Management System******************************");
            Console.WriteLine("1.Add Customer \n2.List All Customers \n3.Search Customer By CustomerID \n4.Serialize All Customers \n5.Deserialize All Customers");
            Console.WriteLine("**********************************************************************************");
        }

        //Adding Customer
        public static void AddCustomerPL()
        {
            try
            {
                Console.WriteLine("Enter Customer ID:");
                string CustomerId = Console.ReadLine();
                Console.WriteLine("Enter Customer Name:");
                string CustomerName = Console.ReadLine();
                Console.WriteLine("Enter Customer PANNumber:");
                string PANNumber = Console.ReadLine();
                Console.WriteLine("Enter FacilitiesRequired:");
                string FacilitiesRequired = Console.ReadLine();
                Console.WriteLine("Enter InitialPayment:");
                int InitialPayment = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter DateOfBirth:");
                DateTime DateOfBirth = DateTime.Parse(Console.ReadLine());



                Customer newCustomer = new Customer();
                newCustomer.CustomerID = CustomerId;
                newCustomer.CustomerName = CustomerName;
                newCustomer.PANNumber = PANNumber;
                newCustomer.DateOfBirth = DateOfBirth;
                newCustomer.FacilitiesRequired = FacilitiesRequired;
                newCustomer.InitialPayment = InitialPayment;




                bool isNewCustomerAdded = CustomerBLL.AddCustomerBLL(newCustomer);
                if (isNewCustomerAdded)
                {
                    Console.WriteLine("Customer Added Successfully");
                }
                else
                {
                    Console.WriteLine("Failed to Add Customer");
                }

            }

            catch (CustomerExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }



        //Getting Customers List
        public static void GetAllCustomersPL()
        {
            List<Customer> CustomersList = CustomerBLL.GetAllCustomersBLL();
            GetDetails(CustomersList);


        }


        //Searching Customers By ID
        public static void SearchDealeerByCustomerIDPL()
        {
            Console.WriteLine("Enter CustomerID");
            string CustomerID = Console.ReadLine();
            List<Customer> SearchedCustomers = CustomerBLL.SearchByCustomerIDBLL(CustomerID);
            GetDetails(SearchedCustomers);
        }



        //Serialize Customers
        public static void SerializeCustomersPL()
        {
            if (CustomerBLL.SerializeCustomersBLL())
            {
                Console.WriteLine("Customer details Serialized Successfully");
            }
            else
            {
                Console.WriteLine("Failed to Serialize Customer Details");
            }
        }




        //Deserialize Customers
        public static void DeserializedCustomersPL()
        {
            List<Customer> DeserializedCustomers = CustomerBLL.DeserializedCustomersBLL();
            Console.WriteLine("Deserialized Data:");
            GetDetails(DeserializedCustomers);

        }



        public static void GetDetails(List<Customer> list)
        {
            Console.WriteLine("----------------------------------------------------------------------------------------");
            Console.WriteLine("CustomerID " + "\t" + "Customer Name" + "\t"
                   + "Date of Birth" + "\t" + "PANNumber " + "\t" + "FacilitiesRequired" + "\t" + "InitialPayment");
            Console.WriteLine("----------------------------------------------------------------------------------------");
            foreach (Customer Customer in list)
            {
                Console.WriteLine(Customer.CustomerID + "\t" + Customer.CustomerName + "\t"
                   + Customer.DateOfBirth + "\t" + Customer.PANNumber + "\t" + Customer.FacilitiesRequired + "\t" + Customer.InitialPayment);
            }
            Console.WriteLine("----------------------------------------------------------------------------------------");

        }

    }
}
