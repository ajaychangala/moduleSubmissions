﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using BSNLCMS_DAL;             //Reference of Data Access Layer
using BSNLCMS_ENTITY;          //Reference of Entity Layer
using BSNLCMS_EXCEPTIONS;      //Reference of Exception Layer

namespace BSNLCMS_BLL
{/// <summary>
/// EmpId:180779
/// Author: Changala Ajay kumar
/// Date of Creation:28-05-2019
/// Description: Business Logic Layer
/// </summary>
    public class CustomerBLL
    {
        CustomerDAL CustomerDAL = new CustomerDAL();
        public bool AddCustomerBLL(Customer newCustomer)
        {
            bool isCustomerAdded = false;
            //To be Implimented
            if (ValidateCustomer(newCustomer))
            {
                isCustomerAdded = CustomerDAL.AddCustomerDAL(newCustomer);
            }
            return isCustomerAdded;

        }
        //Customer validations
        private static bool ValidateCustomer(Customer Customer)
        {
            bool validCustomer = true;
            StringBuilder message = new StringBuilder();

            //Validating CustomerID
            if ((Customer.CustomerID == string.Empty || Customer.CustomerID == null) )
            {
                message.Append(Environment.NewLine + "Invalid Customer Id");
                validCustomer = false;
            }

            //Validating CustomerName
            if (Customer.CustomerName == string.Empty || Customer.CustomerName == null)
            {
                message.Append(Environment.NewLine + "Invalid Customer Name");
                validCustomer = false;
            }

            //Validating Customer Age
            int age = DateTime.Today.Year - Customer.DateOfBirth.Year;
            if (age < 18 )
            {
                message.Append(Environment.NewLine + "As per the Date of Birth Customer age should be above 18 ");
                validCustomer = false;

            }

            //Validating InitialPayment
            if ( Customer.InitialPayment == null && Customer.InitialPayment <= 500)
            {
                message.Append(Environment.NewLine + "Invalid InitialPayment");
                validCustomer = false;
            }

            //Validating Facilities Required
            if ((Customer.FacilitiesRequired == string.Empty || Customer.FacilitiesRequired == null) && (Customer.FacilitiesRequired.ToLower() != "broadband" || Customer.FacilitiesRequired.ToLower() != "std"
                || Customer.FacilitiesRequired.ToLower() != "isd"))
            {
                message.Append(Environment.NewLine + "Invalid Customer Catagory");
                validCustomer = false;
            }


            //Validating Pan number details
            if ((Customer.PANNumber == string.Empty || Customer.PANNumber == null) || !Regex.IsMatch(Customer.PANNumber, @"[A-Z]{5}[0-9]{3}[A-Z]{1}"))
            {
                message.Append(Environment.NewLine + "Invalid PAN Number");
                validCustomer = false;
            }
            if (validCustomer == false)
            {
                throw new CustomerExceptions(message.ToString());
            }
            return validCustomer;
        }
        

        //Listing customers
        public List<Customer> GetAllCustomersBLL()
        {
            return CustomerDAL.GetAllCustomersDal();
        }

        //Search Customers
        public List<Customer> SearchByCustomerIDBLL(string CustomerCategory)
        {
            return CustomerDAL.SearchByCustomerIDDal(CustomerCategory);
        }


        //Serialize Customers
        public bool SerializeCustomersBLL()
        {
            return CustomerDAL.SerializeCustomersDal();
        }

        //Deserialize Customers
        public List<Customer> DeserializedCustomersBLL()
        {
            return CustomerDAL.DeserializedCustomersDal();
        }
    }
}

