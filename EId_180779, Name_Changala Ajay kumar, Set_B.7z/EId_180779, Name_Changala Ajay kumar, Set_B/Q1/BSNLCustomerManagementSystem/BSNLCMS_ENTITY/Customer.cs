﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSNLCMS_ENTITY
{
    /// <summary>
    /// EmpId:180779
    /// Author: Changala Ajay kumar
    /// Date of Creation:28-05-2019
    /// Description: Entity Layer
    /// </summary>
    /// 
    [Serializable]
    public class Customer
    {
        //Properties of Customer
        public string CustomerID { get; set; }
        public string CustomerName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string EmailAddress { get; set; }
        public string PANNumber { get; set; }
        public string FacilitiesRequired { get; set; }
        public int InitialPayment { get; set; }
    }
}
