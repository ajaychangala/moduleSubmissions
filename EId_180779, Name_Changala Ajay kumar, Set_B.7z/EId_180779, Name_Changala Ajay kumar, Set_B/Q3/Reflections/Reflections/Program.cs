﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Reflections
{
    /// <summary>
    /// Employee Id: 180779
    /// Author: Changala Ajay kumar
    /// Date of Creation: 28-05-2019
    /// </summary>
    class Program
    {
        //Main Method
        static void Main(string[] args)
        {
            //Extract metadata of Assembly or Reflection
            Console.WriteLine("Enter path of any Directory:");
            string pathofDirectory = Console.ReadLine();
            Assembly assembly = Assembly.LoadFrom(pathofDirectory);
           
            Type[] types = assembly.GetTypes();
            foreach (Type t in types)
            {
                Console.WriteLine(t.FullName);
                MethodInfo[] methodInfos = t.GetMethods();
                Console.WriteLine("\n\t Methods from " + t.Name);
                foreach (MethodInfo mi in methodInfos)
                {
                    Console.WriteLine(mi.ReturnType.Name + " " + mi.Name + "(" + ")");
                }

                PropertyInfo[] props = t.GetProperties();
                Console.WriteLine("\n\t Properties from " + t.Name);
                foreach (PropertyInfo pi in props)
                {
                    Console.WriteLine(pi.ToString());
                }

                FieldInfo[] fls = t.GetFields();
                Console.WriteLine("\n\t Fields from " + t.Name);
                foreach (FieldInfo fi in fls)
                {
                    Console.WriteLine(fi.ToString());
                }
                
            }
            Console.ReadLine();
        }
    }
}
